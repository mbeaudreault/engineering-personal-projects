#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "assert.h"
#include "a2methods.h"
#include "a2plain.h"
#include "a2blocked.h"
#include "pnm.h"
#include "mem.h"

void rotateImage(Pnm_ppm inputImage, int rotation, A2Methods_mapfun *map);
void applyRotate90(int i, int j, void* array, void *elem, void *cl);
void applyRotate180(int i, int j, void* array, void *elem, void *cl);
void printImage(void* imageArray, Pnm_ppm inputImage, int rotation);

int main(int argc, char *argv[]) {
  assert(argc > 2);

  int rotation = 0;
  Pnm_ppm inputImage;

  A2Methods_T methods = array2_methods_plain; // default to Array2 methods
  assert(methods);
  A2Methods_mapfun *map = methods->map_default; // default to best map
  assert(map);
#define SET_METHODS(METHODS, MAP, WHAT) do { \
      methods = (METHODS); \
      assert(methods); \
      map = methods->MAP; \
      if (!map) { \
        fprintf(stderr, "%s does not support " WHAT "mapping\n", argv[0]); \
        exit(1); \
      } \
    } while(0)

  int i;
  for (i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "-row-major")) {
      SET_METHODS(array2_methods_plain, map_row_major, "row-major");
    } else if (!strcmp(argv[i], "-col-major")) {
      SET_METHODS(array2_methods_plain, map_col_major, "column-major");
    } else if (!strcmp(argv[i], "-block-major")) {
      SET_METHODS(array2_methods_blocked, map_block_major, "block-major");
    } else if (!strcmp(argv[i], "-rotate")) {
      assert(i + 1 < argc);
      char *endptr;
      rotation = strtol(argv[++i], &endptr, 10);
      assert(*endptr == '\0'); // parsed all correctly
      assert(rotation == 0   || rotation == 90
          || rotation == 180 || rotation == 270);
    } else if((!strcmp(argv[i], "-flip")) || (!strcmp(argv[i], "-transpose"))){
      fprintf(stderr, "%s is not supported\n", argv[i]);
      exit(1);
    }else if (*argv[i] == '-') {
      fprintf(stderr, "%s: unknown option '%s'\n", argv[0], argv[i]);
      exit(1);
    } else if (argc - i > 2) {
      fprintf(stderr, "Usage: %s [-rotate <angle>] "
              "[-{row,col,block}-major] [filename]\n", argv[0]);
      exit(1);
    }

    // prog, rotate, num, major order = 4
    // prog, rotate, num, major order, file name = 5
    if(argc == 4){
      // use stdin
      inputImage = Pnm_ppmread(stdin, methods);
      break;
    }else if(argc == 5){
      // use file
        FILE *fp;
        fp = fopen(argv[4], "r");
      inputImage = Pnm_ppmread(fp, methods);
      fclose(fp);
      break;
    }
  }

  rotateImage(inputImage, rotation, map);
  Pnm_ppmfree(&inputImage);
}

void applyRotate90(int i, int j, void* array, void *elem, void *cl){
  (void)elem;
  int height = ((Pnm_ppm)cl)->height;
  int oldI = j;
  int oldJ = height - i - 1;

  struct Pnm_rgb* oldPixel = 
  (((Pnm_ppm)cl)->methods->at)(((Pnm_ppm)cl)->pixels, oldI, oldJ);
  struct Pnm_rgb* newPixel = (((Pnm_ppm)cl)->methods->at)(array, i, j);

  *newPixel = *oldPixel;
}

void applyRotate180(int i, int j, void* array, void *elem, void *cl){
  (void) array;
  (void)elem;
  int height = ((Pnm_ppm)cl)->height;
  int width = ((Pnm_ppm)cl)-> width;
  int newI = width - i - 1;
  int newJ = height - j - 1;

  struct Pnm_rgb* oldPixel = 
  (((Pnm_ppm)cl)->methods->at)(((Pnm_ppm)cl)->pixels, i, j);
  struct Pnm_rgb* newPixel = (((Pnm_ppm)cl)->methods->at)(array, newI, newJ);

  *newPixel = *oldPixel;

}

void rotateImage(Pnm_ppm inputImage, int rotation, A2Methods_mapfun *map){

  const struct A2Methods_T *methods = inputImage->methods;
  void* imageArray;
  
  if(rotation == 90){
    
    imageArray = (methods->new)(inputImage->height, inputImage->width,
    sizeof(struct Pnm_rgb));
    (*map)(imageArray, applyRotate90, inputImage);

  }else if(rotation == 180){
    imageArray = (methods->new)(inputImage->width,inputImage->height,
    sizeof(struct Pnm_rgb));
    (*map)(imageArray, applyRotate180, inputImage);

  }else{
    fprintf(stderr, "%d degree rotation not supported\n", rotation);
  }

  printImage(imageArray, inputImage, rotation);

  (methods->free)(&imageArray);
}

void printImage(void* imageArray, Pnm_ppm inputImage, int rotation){
  unsigned height = 0;
  unsigned width = 0;
  if(rotation == 90){
    height = inputImage->width;
    width = inputImage->height;
  } else if (rotation == 180){
    height = inputImage->height;
    width = inputImage->width;
  }


  printf("P3\n");
  printf("%d %d\n", width, height);
  printf("%d\n", inputImage->denominator);
  for(unsigned i = 0; i < height; i++){
    for(unsigned j = 0; j < width; j++){

      void* test = (inputImage->methods->at)(imageArray, j, i);

      printf("%u %u %u  ", ((Pnm_rgb)test)->red, ((Pnm_rgb)test)->green,
      ((Pnm_rgb)test)->blue);
    }
    printf("\n");
  }

}
