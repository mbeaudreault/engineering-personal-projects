#include "decompression.h"
#include "compression.h"

void getYPbPr(unsigned a, int b, int c, int d, unsigned pb, unsigned pr, A2Methods_Array2 YPbPrArray, unsigned i, unsigned j){
  Pnm_float_YPbPr pixel1 = (array2_methods_plain->at)(YPbPrArray, j, i);
  Pnm_float_YPbPr pixel2 = (array2_methods_plain->at)(YPbPrArray, j, i+1);
  Pnm_float_YPbPr pixel3 = (array2_methods_plain->at)(YPbPrArray, j+1, i);
  Pnm_float_YPbPr pixel4 = (array2_methods_plain->at)(YPbPrArray, j+1, i+1);

  float pbFloat = Arith_chroma_of_index(pb);
  float prFloat = Arith_chroma_of_index(pr);

    /*pixel1->Y = a - b - c + d;
    pixel2->Y = a - b + c - d;
    pixel3->Y = a + b - c - d;
    pixel4->Y = a + b + c + d;*/

    //if((a > 511) || b < -15 || b > 15 || c < -15 || c > 15 || d < -15 || d > 15){
      //printf("a = %d, b = %d, c = %d, d = %d\n", a, b, c, d);
    //}

	float aFloat = ((float)a)/511.0;
	float bFloat = ((float)b)/50.0;
	float cFloat = ((float)c)/50.0;
	float dFloat = ((float)d)/50.0;

	//if(aFloat < 0) aFloat = 0;
	//if(bFloat < 0) bFloat = 0;
	//if(cFloat < 0) cFloat = 0;
	//if(dFloat < 0) dFloat = 0;

	//if(aFloat > 1) aFloat = 1;
	//if(bFloat > 1) bFloat = 1;
	//if(cFloat > 1) cFloat = 1;
	//if(dFloat > 1) dFloat = 1;


  //if(aFloat > 1 || bFloat < -0.31 || bFloat > 0.31 || cFloat < -0.31 || cFloat > 0.31 || dFloat < -0.31 || dFloat > 0.31){
    //printf("aF = %f, bF = %f, cF = %f, dF = %f\n", aFloat, bFloat, cFloat, dFloat);
  //}

  ////printf("a = %u, b = %d, c = %d, d = %d\n", a, b, c, d);
  //printf("aFloat = %f, bFloat = %f, cFloat = %f, dFloat = %f\n\n", aFloat, bFloat, cFloat, dFloat);

	pixel1->Y = aFloat - bFloat - cFloat + dFloat;
  pixel2->Y = aFloat - bFloat + cFloat - dFloat;
  pixel3->Y = aFloat + bFloat - cFloat - dFloat;
  pixel4->Y = aFloat + bFloat + cFloat + dFloat;

  pixel1->Pb = pbFloat;
  pixel1->Pr = prFloat;

  pixel2->Pb = pbFloat;
  pixel2->Pr = prFloat;

  pixel3->Pb = pbFloat;
  pixel3->Pr = prFloat;

  pixel4->Pb = pbFloat;
  pixel4->Pr = prFloat;

  //printf("pixel1->Y = %f, pixel1->Pb = %f, pixel1->Pr = %f\n", pixel1->Y, pixel1->Pb, pixel1->Pr);
}

A2Methods_Array2 YPbPrtoRGB(A2Methods_Array2 YPbPrArray, A2Methods_Array2 rgbDecompressedFloatArray, unsigned width, unsigned height){
  for(unsigned i = 0; i < height; i++){
    for(unsigned j = 0; j < width; j++){
      Pnm_float_YPbPr tempPixel = (array2_methods_plain->at)(YPbPrArray, j, i);
      Pnm_float_rgb newPixel = (array2_methods_plain->at)(rgbDecompressedFloatArray, j, i);
      //

      /* Good formula:*/
      newPixel->red = (1.0 * tempPixel->Y) + (0.0 * tempPixel->Pb) + (1.402 * tempPixel->Pr);
      newPixel->green = (1.0 * tempPixel->Y) - (0.344136 * tempPixel->Pb) - (0.714136 * tempPixel->Pr);
      newPixel->blue = (1.0 * tempPixel->Y) + (1.772 * tempPixel->Pb) + (0.0 * tempPixel->Pr);

      //if((newPixel->red < 0.19 && newPixel->green < 0.19 && newPixel->blue < 0.19) || (newPixel->red > 0.78 && newPixel->green > 0.78 && newPixel->blue > 0.78)){
        //printf("Y = %f, Pb = %f, Pr = %f, i = %u, j = %u\n", tempPixel->Y, tempPixel->Pb, tempPixel->Pr, i, j);
      //}

	    if(newPixel->red < 0) newPixel->red = 0;
	    if(newPixel->green < 0) newPixel->green = 0;
	    if(newPixel->blue < 0) newPixel->blue = 0;

	  if(newPixel->red > 1) newPixel->red = 1;
	  if(newPixel->green > 1) newPixel->green = 1;
	  if(newPixel->blue > 1) newPixel->blue = 1;

      /*
      newPixel->red = (1.0 * tempPixel->Y) + (0.0 * tempPixel->Pb) + (14.02 * tempPixel->Pr);
      newPixel->green = (1.0 * tempPixel->Y) - (3.44136 * tempPixel->Pb) - (7.14136 * tempPixel->Pr);
      newPixel->blue = (1.0 * tempPixel->Y) + (17.72 * tempPixel->Pb) + (0.0 * tempPixel->Pr);
      */

      //(void)tempPixel;

      //printf("i = %u, j = %u red = %f, blue = %f, green = %f\n\n", i, j, newPixel->red, newPixel->blue, newPixel->green);

    }
  }
  return rgbDecompressedFloatArray;
}

void floatRGBtoPpmRGB(struct Pnm_ppm pixmap, A2Methods_Array2 rgbDecompressedFloatArray){
  for(unsigned i = 0; i < pixmap.height; i++){
    for(unsigned j = 0; j < pixmap.width; j++){
      Pnm_float_rgb tempPixel = (array2_methods_plain->at)(rgbDecompressedFloatArray, j, i);

      Pnm_rgb newPixel = (array2_methods_plain->at)(pixmap.pixels, j, i);

	  //printf("i = %u, j = %u red = %f, blue = %f, green = %f\n", i, j, tempPixel->red, tempPixel->blue, tempPixel->green);

	  unsigned redU = tempPixel->red * pixmap.denominator;
	  unsigned greenU = tempPixel->green * pixmap.denominator;
	  unsigned blueU = tempPixel->blue * pixmap.denominator;

      newPixel->red = redU;
      newPixel->green = greenU;
      newPixel->blue = blueU;

	  //printf("i = %u, j = %u red = %u, blue = %u, green = %u\n\n", i, j, newPixel->red, newPixel->blue, newPixel->green);
    }
  }
}
