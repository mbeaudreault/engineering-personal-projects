#include "memAccess.h"
#include "mem.h"
#include "array.h"
#include "string.h"

#define INITIAL_MEMORY_SIZE 65536

// Sequence of segments that represent universal machine's memory
Seq_T m;

// Sequence giving the size of each activated segment
Seq_T numWordsArray;

// Sequence of segment IDs that have been deactivated/unmapped
Seq_T unmapped;

// The leargest segment ID that has previously been activated
uint32_t highWaterMark;

void initializeMemory(uint32_t numWords){

    m = Seq_new(INITIAL_MEMORY_SIZE);
    numWordsArray = Seq_new(INITIAL_MEMORY_SIZE);
    unmapped = Seq_new(INITIAL_MEMORY_SIZE);

    uint32_t* segment = calloc(numWords, sizeof(uint32_t));
    Seq_addhi(numWordsArray, (void *)(uintptr_t)numWords);
    Seq_addhi(m, segment);

    highWaterMark = 0;
}

uint32_t activateSegment(uint32_t numWords){
    uint32_t segNum;

    uint32_t* segment = calloc(numWords, sizeof(uint32_t));
    if(segment == NULL){
        fprintf(stderr, "segment is null\n");
    }

    if(Seq_length(unmapped) == 0){
        // Create a new segment
        highWaterMark += 1;
        segNum = highWaterMark;
        Seq_addhi(m, segment);
        Seq_addhi(numWordsArray,(void *)(uintptr_t)numWords);
    }else{
        // Use a deactivated segment
        segNum = (uint32_t)(uintptr_t)Seq_remhi(unmapped);
        Seq_put(m, segNum, segment);
        Seq_put(numWordsArray, segNum, (void *)(uintptr_t)numWords);
    }
    return segNum;
}

void deactivateSegment(uint32_t segNum){
    Seq_addhi(unmapped, (void*)(uintptr_t)segNum);
    free(Seq_get(m, segNum));
}

uint32_t getMemoryAt(uint32_t segNum, uint32_t memLoc){

    uint32_t numWords = (uint32_t)(uintptr_t)Seq_get(numWordsArray, segNum);

    if((segNum > highWaterMark) || (memLoc > numWords)){
        return 0;
    }

    uint32_t* segment = Seq_get(m, segNum);

    return segment[memLoc];
}

void setMemoryAt(uint32_t segNum, uint32_t memLoc, uint32_t inputValue){
    uint32_t* segment = Seq_get(m, segNum);
    segment[memLoc] = inputValue;
}

uint32_t getNumWords(uint32_t segNum){
    uint32_t numWords = (uint32_t)(uintptr_t)Seq_get(numWordsArray, segNum);
    return numWords;
}

void moveSegment(uint32_t oldSegNum, uint32_t newSegNum){
    free(Seq_get(m, newSegNum));

    uint32_t* tempSegment = Seq_get(m, oldSegNum);
    uint32_t numWords = getNumWords(oldSegNum);
    uint32_t* newSegment = calloc(numWords, sizeof(uint32_t));

    if(newSegment == NULL){
        fprintf(stderr, "new segment is null\n");
    }

    Seq_put(numWordsArray, 0, (void *)(uintptr_t)numWords);

  memcpy(newSegment, tempSegment, numWords*4);
    Seq_put(m, newSegNum, newSegment);
}

void freeAllMemory(){
    for(int i = 0; i < Seq_length(unmapped); i++){
        uint32_t segNum = (uint32_t)(uintptr_t)Seq_remhi(unmapped);
        free(Seq_get(m, segNum));
    }

    Seq_free(&m);
    Seq_free(&numWordsArray);
    Seq_free(&unmapped);
}
