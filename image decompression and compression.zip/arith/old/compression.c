#include "compression.h"

A2Methods_Array2 formatImage(Pnm_ppm image){


	if((image->height % 2)!= 0){
		image->height -= 1;
	}
	if((image->width % 2)!= 0){
		image->width -= 1;
	}

	A2Methods_Array2 floatArray = (image->methods->new)(image->width, image->height, sizeof(struct Pnm_float_rgb));

  //printf("width = %d, height = %d\n", image->width, image->height);
	for(unsigned i = 0; i < image->height; i++){
		for(unsigned j = 0; j < image->width; j++){
      //may cause issues with bounds
			Pnm_rgb tempPixel = (image->methods->at)(image->pixels, j, i);
			Pnm_float_rgb newPixel = (image->methods->at)(floatArray, j, i);
      newPixel->red = (((float)tempPixel->red) / ((float)image->denominator));
      newPixel->green = (((float)tempPixel->green) / ((float)image->denominator));
      newPixel->blue = (((float)tempPixel->blue) / ((float)image->denominator));

      //printf("r %f g %f b %f\n", newPixel->red, newPixel->green, newPixel->blue);
		}
	}

  //printf("r = %f\n", ((Pnm_float_rgb)((image->methods->at)(floatArray, 1, 0)))->blue);
  return floatArray;
}

A2Methods_Array2 RGBtoYPbPr(A2Methods_Array2 floatArray, Pnm_ppm image){
  A2Methods_Array2 componentArray = (image->methods->new)(image->width, image->height, sizeof(struct Pnm_float_YPbPr));

  for(unsigned i = 0; i < image->height; i++){
    for(unsigned j = 0; j < image->width; j++){
      Pnm_float_rgb tempPixel = (image->methods->at)(floatArray, j, i);
      Pnm_float_YPbPr newPixel = (image->methods->at)(componentArray, j, i);
      newPixel->Y = (0.299 * tempPixel->red)+(0.587 * tempPixel->green)+(0.114 * tempPixel->blue);
      newPixel->Pb = (-0.168736 * tempPixel->red)-(0.331264 * tempPixel->green)+(0.5 * tempPixel->blue);
      newPixel->Pr = (0.5* tempPixel->red)-(0.418688 * tempPixel->green)-(0.081312 * tempPixel->blue);
      //printf("y = %f, Pb = %f, Pr = %f, i = %u, j = %u\n", newPixel->Y, newPixel->Pb, newPixel->Pr, i, j);
    }
  }
  return componentArray;
}

A2Methods_Array2 pack2by2(A2Methods_Array2 componentArray, Pnm_ppm image){
  A2Methods_Array2 wordArray = (image->methods->new)(image->width, image->height, sizeof(uint64_t));

  for(unsigned i = 0; i < image->height; i += 2){
    for(unsigned j = 0; j < image->width; j += 2){
      Pnm_float_YPbPr pixel1 = (image->methods->at)(componentArray, j, i);
      Pnm_float_YPbPr pixel2 = (image->methods->at)(componentArray, j, i+1);
      Pnm_float_YPbPr pixel3 = (image->methods->at)(componentArray, j+1, i);
      Pnm_float_YPbPr pixel4 = (image->methods->at)(componentArray, j+1, i+1);

      float PbAvg = ((pixel1->Pb + pixel2->Pb + pixel3->Pb + pixel4->Pb) / 4.0);
      float PrAvg = ((pixel1->Pr + pixel2->Pr + pixel3->Pr + pixel4->Pr) / 4.0);

      unsigned PbAvg4b = Arith_index_of_chroma(PbAvg);
      unsigned PrAvg4b = Arith_index_of_chroma(PrAvg);

      //printf("PbAvg = %f, PrAvg = %f, i = %u, j = %u\n", PbAvg, PrAvg, i, j);
      //printf("PbAvg4b = %u, PrAvg4b = %u, i = %u, j = %u\n", PbAvg4b, PrAvg4b, i, j);

      float aFloat = ((pixel4->Y + pixel3->Y + pixel2->Y + pixel1->Y)/4.0);
      float bFloat = ((pixel4->Y + pixel3->Y - pixel2->Y - pixel1->Y)/4.0);
      float cFloat = ((pixel4->Y - pixel3->Y + pixel2->Y - pixel1->Y)/4.0);
      float dFloat = ((pixel4->Y - pixel3->Y - pixel2->Y + pixel1->Y)/4.0);

			//if((aFloat < 0 || aFloat > 1) || bFloat < -0.5 || bFloat > 0.5 || cFloat < -0.5 || cFloat > 0.5 || dFloat < -0.5 || dFloat > 0.5){
				//printf("aFloat = %f, bFloat = %f, cFloat = %f, dFloat = %f\n", aFloat, bFloat, cFloat, dFloat);
			//}
      unsigned a = (unsigned)(round(aFloat * 511.0));
      int b = floatToSigned(bFloat);
      int c = floatToSigned(cFloat);
      int d = floatToSigned(dFloat);

			//if((a > 511) || b < -15 || b > 15 || c < -15 || c > 15 || d < -15 || d > 15){
			//printf("a = %d, bFloat = %f, c = %d, d = %d\n", a, bFloat, c, d);
			//}

      uint64_t word = 0;
      word = Bitpack_newu(word, 9, 23, a);
      word = Bitpack_news(word, 5, 18, (int64_t)b);
      word = Bitpack_news(word, 5, 13, (int64_t)c);
      word = Bitpack_news(word, 5, 8, (int64_t)d);
      word = Bitpack_newu(word, 4, 4, PbAvg4b);
      word = Bitpack_newu(word, 4, 0, PrAvg4b);

      uint64_t *tempWord = (image->methods->at)(wordArray, j, i);
      //(void) tempWord;
      //printf("word = %lx, i = %u, j= %u\n", word, i, j);
      *tempWord = word;
      //printf("tempWord = %lx\n", *tempWord);

      //uint64_t *newTempWord = (image->methods->at)(wordArray, j, i);
      //printf("newTempword = %lx\n", *newTempWord);

      //printf("a = %u, b = %d, c = %d, d = %d, i = %u, j = %u\n", a, b, c, d, i, j);
      //(void)a;
      //(void)b;
      //(void)c;
      //(void)d;
    }
  }
  return wordArray;
}

int floatToSigned(float xfloat){
  if(xfloat <= -0.3){
    return -15;
  }else if (xfloat >= 0.3){
    return 15;
  }else{
    xfloat *= 50.0;
    int x = (int)(round(xfloat));
    return x;
  }
}

void printCompressed(A2Methods_Array2 wordArray, Pnm_ppm image){
  (void) wordArray;
  printf("Compressed image format 2\n%u %u", image->width, image->height);
  printf("\n");
  for(unsigned i = 0; i < (image->height); i += 2){
    for(unsigned j = 0; j < (image->width); j+=2 ){
      uint64_t *tempWord = (image->methods->at)(wordArray, j, i);
      //printf("tempWord = %lx\n", *tempWord);
      putchar(Bitpack_getu(*tempWord, 8, 24));
      putchar(Bitpack_getu(*tempWord, 8, 16));
      putchar(Bitpack_getu(*tempWord, 8, 8));
      putchar(Bitpack_getu(*tempWord, 8, 0));

    }
  }
}
