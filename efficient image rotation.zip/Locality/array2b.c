#include "a2methods.h"
#include <stdio.h>
#include <stdlib.h>
#include "array2.h"
#include "array2b.h"
#include <math.h>
#include "array.h"
#include "mem.h"

struct Array2b_T {
  int width;
  int height;
  int size;
  int blocksize;
  Array2_T blockArray;
};

Array2b_T Array2b_new(int width, int height, int size, int blocksize){

  int numHorizontalBlocks =  ceil(((float)width)/((float)blocksize));
  int numVerticalBlocks = ceil(((float)height)/((float)blocksize));

  Array2b_T output;
  NEW(output);

  output->width = width;
  output->height = height;
  output->size = size;
  output->blocksize = blocksize;
  output->blockArray = Array2_new(numHorizontalBlocks, numVerticalBlocks,
  sizeof(Array_T*));

    for(int i = 0; i < numHorizontalBlocks; i++){
        for(int j = 0; j < numVerticalBlocks; j++){
            Array_T* blockPixels = Array2_at(output->blockArray, i, j);
            *blockPixels = Array_new(blocksize * blocksize, size);
        }
    }

  return output;
}

Array2b_T Array2b_new_64K_block(int width, int height, int size){
  // 64 * 1024
  // be careful with rounding
  //take the floor
  int blocksize = (int)floor(sqrt(65536.0 / (float)size));
  if(blocksize < 1){
    blocksize = 1;
  }
    printf("new 64\n");

  return Array2b_new(width, height, size, blocksize);
}

void Array2b_free (Array2b_T *array2b){
  int width = ((*array2b)->width) / ((*array2b)->blocksize);
  int height = ((*array2b)->height)/((*array2b)->blocksize);

    for(int i = 0; i < width; i++){
        for(int j = 0; j < height; j++){
      Array_free(Array2_at((*array2b)->blockArray, i, j));
        }
    }
  Array2_free(&((*array2b)->blockArray));
  printf("freed\n");
}

int Array2b_width (Array2b_T array2b){
  return array2b->width;
}

int Array2b_height(Array2b_T array2b){

  return array2b->height;
}

int Array2b_size (Array2b_T array2b){

  return array2b->size;
}

int Array2b_blocksize(Array2b_T array2b){
  return array2b->blocksize;
}

void* Array2b_at(Array2b_T array2b, int i, int j){
    int blocksize = array2b->blocksize;
    int index = (blocksize * (i % blocksize)) + (j % blocksize);
    Array_T* tempArray = Array2_at(array2b->blockArray, (i / blocksize), (j / blocksize));

    return Array_get(*tempArray, index);
}

void Array2b_map(Array2b_T array2b, void apply(int i, int j,
 Array2b_T array2b, void *elem, void *cl), void *cl){
  int blocksize = array2b->blocksize;
  int numHorizontalBlocks =  ceil(((float)(array2b->width))/((float)blocksize));
    int numVerticalBlocks = ceil(((float)(array2b->height))/((float)blocksize));

  for(int blockI = 0; blockI < numHorizontalBlocks; blockI++){
        for(int blockJ = 0; blockJ < numVerticalBlocks; blockJ++){
      Array_T* blockPixels = Array2_at(array2b->blockArray, blockI, blockJ);
            for(int cellIndex = 0; cellIndex < blocksize * blocksize; cellIndex++){
        int j = (blockJ * blocksize) + (cellIndex % blocksize);
        int i = (blockI * blocksize) + (floor(cellIndex / blocksize));
        if(i < array2b->width && j < array2b->height){
          apply(i, j, array2b, Array_get(*blockPixels, cellIndex), cl);
        }
      }
        }
    }
}
