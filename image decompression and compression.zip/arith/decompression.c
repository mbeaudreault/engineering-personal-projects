#include "decompression.h"
#include "compression.h"

void getYPbPr(unsigned a, int b, int c, int d, unsigned pb, unsigned pr,
 A2Methods_Array2 YPbPrArray, unsigned i, unsigned j){
  Pnm_float_YPbPr pixel1 = (array2_methods_plain->at)(YPbPrArray, j, i);
  Pnm_float_YPbPr pixel2 = (array2_methods_plain->at)(YPbPrArray, j, i+1);
  Pnm_float_YPbPr pixel3 = (array2_methods_plain->at)(YPbPrArray, j+1, i);
  Pnm_float_YPbPr pixel4 = (array2_methods_plain->at)(YPbPrArray, j+1, i+1);

  float pbFloat = Arith_chroma_of_index(pb);
  float prFloat = Arith_chroma_of_index(pr);

  float aFloat = ((float)a)/511.0;
  float bFloat = ((float)b)/50.0;
  float cFloat = ((float)c)/50.0;
  float dFloat = ((float)d)/50.0;

  pixel1->Y = aFloat - bFloat - cFloat + dFloat;
  pixel2->Y = aFloat - bFloat + cFloat - dFloat;
  pixel3->Y = aFloat + bFloat - cFloat - dFloat;
  pixel4->Y = aFloat + bFloat + cFloat + dFloat;

  pixel1->Pb = pbFloat;
  pixel1->Pr = prFloat;

  pixel2->Pb = pbFloat;
  pixel2->Pr = prFloat;

  pixel3->Pb = pbFloat;
  pixel3->Pr = prFloat;

  pixel4->Pb = pbFloat;
  pixel4->Pr = prFloat;

}

A2Methods_Array2 YPbPrtoRGB(A2Methods_Array2 YPbPrArray, 
A2Methods_Array2 rgbDecompressedFloatArray, unsigned width, unsigned height){
  for(unsigned i = 0; i < height; i++){
    for(unsigned j = 0; j < width; j++){
      Pnm_float_YPbPr tempPixel = (array2_methods_plain->at)(YPbPrArray, j, i);
      Pnm_float_rgb newPixel = (array2_methods_plain->at)
      (rgbDecompressedFloatArray, j, i);
      

      newPixel->red = (1.0 * tempPixel->Y) + (0.0 * tempPixel->Pb) 
      + (1.402 * tempPixel->Pr);
      
      newPixel->green = (1.0 * tempPixel->Y) - (0.344136 * tempPixel->Pb) 
      - (0.714136 * tempPixel->Pr);
      
      newPixel->blue = (1.0 * tempPixel->Y) + (1.772 * tempPixel->Pb)
      + (0.0 * tempPixel->Pr);

        if(newPixel->red < 0) newPixel->red = 0;
        if(newPixel->green < 0) newPixel->green = 0;
        if(newPixel->blue < 0) newPixel->blue = 0;

        if(newPixel->red > 1) newPixel->red = 1;
        if(newPixel->green > 1) newPixel->green = 1;
        if(newPixel->blue > 1) newPixel->blue = 1;

    }
  }
  return rgbDecompressedFloatArray;
}

void floatRGBtoPpmRGB(struct Pnm_ppm pixmap, 
A2Methods_Array2 rgbDecompressedFloatArray){
  for(unsigned i = 0; i < pixmap.height; i++){
    for(unsigned j = 0; j < pixmap.width; j++){
      Pnm_float_rgb tempPixel = (array2_methods_plain->at)
      (rgbDecompressedFloatArray, j, i);

      Pnm_rgb newPixel = (array2_methods_plain->at)(pixmap.pixels, j, i);

      unsigned redU = tempPixel->red * pixmap.denominator;
      unsigned greenU = tempPixel->green * pixmap.denominator;
      unsigned blueU = tempPixel->blue * pixmap.denominator;

      newPixel->red = redU;
      newPixel->green = greenU;
      newPixel->blue = blueU;
    }
  }
}
