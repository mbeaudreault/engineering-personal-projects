#include "stack.h"

Node::Node(int value){
    data = value;
    next = NULL;
}

Node::~Node(){
    
}

ListStack::ListStack(){
    head = NULL;
    tail = NULL;
    n_elem = 0;
}

void ListStack::push(int value){
    Node *newNode = new Node(value);
    if(n_elem == 0){
        head = newNode;
        tail = newNode;
    }else{
        tail->next = newNode;
        tail = newNode;
    }
    n_elem++;
}

int ListStack::pop(){
    int data = 0;
    Node *temp = tail;
    if(n_elem == 1){
        head = NULL;
        tail = NULL;
        n_elem--;
        return temp->data;
    }else if(n_elem ==0){
        return 0;
    }else{
        Node *p = head;
        for(int i = 1; i < n_elem -1; i ++ ){
            p = p->next;
        }
        p->next = NULL;
        tail = p;
        n_elem --;
        return temp->data;
    }
}

int ListStack::size() {
    return n_elem;
}

bool ListStack::isEmpty() {
    if(n_elem == 0){
        return true;
    }else{
        return false;
    }
}