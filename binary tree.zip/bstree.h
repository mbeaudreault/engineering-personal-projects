#ifndef __BSTREE_H__
#define __BSTREE_H__
#include<iostream>
#include<vector>

using namespace std;

#ifndef NULL
#define NULL 0x00
#endif

#include <vector>

class BSTNode {
    private:
        // the integer value stored at this node
        int value;
        // count how many occurrences of this integer we have
        unsigned int count;

        BSTNode *left;
        BSTNode *right;

    public:
        BSTNode(const int num) {
            count = 1;
            value = num;
            left = right = NULL;
        }

        ~BSTNode() {
        }

    friend class BSTree;
    friend class MyTree; // necessary for the autograder
};

class BSTree {
    protected:
        BSTNode *root;
        unsigned int n_elem;
        
        //insert node recursive function
        int insert_Node(BSTNode *Node, const int num){
            //if node already exits increment 
            if(num == Node->value){
                Node->count +=1;
            }else if(num > Node->value){
                //add node to right if it belongs
                if(Node->right == NULL){
                    //create new node
                    BSTNode *newNode = new BSTNode(num);
                    Node->right = newNode;
                    return 1;
                }else{
                    // if there is no space for the node call recursively on the right node
                    Node = Node->right;
                    return insert_Node(Node, num);
                }
            }else if(num < Node->value){
                //do the same for length
                if(Node->left == NULL){
                    BSTNode *newNode = new BSTNode(num);
                    Node->left = newNode;
                    return 1;
                }else{
                    Node = Node->left;
                    return insert_Node(Node, num);
                }
            }
        }
        
        //not used function
        int insert_after_remove(BSTNode *node){
            
            
            insert_Node(root, node->value);
            if(node->right == NULL && node->left == NULL){
                return 0;
            }else if(node->right == NULL && node->left != NULL){
                insert_after_remove(node->left);
                return 0;
            }else if(node->right != NULL && node->left == NULL){
                insert_after_remove(node->right);
                return 0;
            }else{
                insert_after_remove(node->right) + insert_after_remove(node->left);
                return 0;
            }
        }
        
        
        
        int remove_node(BSTNode *node, const int num, bool isRoot, BSTNode *parent, bool isSuccessor){
            //if removing a node that has more than one occurence decrease the count
            if(node->value == num && node->count > 1 && isSuccessor == false){
                node->count = node->count - 1;
                //if node is equal the removal or you are removing the successor
            }else if(node->value == num && (node->count == 1 || isSuccessor == true)){
                //Case 1
                if(node->left == NULL && node->right == NULL){
                    if(num > parent->value){
                        parent->right = NULL;
                    }else{
                        parent->left = NULL;
                    }
                    //Case 2 right node
                }else if(node->right == NULL){
                    if(num > parent->value){
                        parent->right = node->left;
                    }else{
                        parent->left = node->left;
                    }
                    //case 2 left node
                }else if(node->left == NULL){
                    if(num > parent->value){
                        parent->right = node->right;
                    }else{
                        parent->left = node->right;
                    }
                    //if removing a successor set parent to not point to it
                }else if(isSuccessor == true){
                    if(num > parent->value){
                        parent->right = NULL;
                    }else{
                        parent->left = NULL;
                    }
                }else{
                    //case 3 creat temp to find successor
                    BSTNode *temp = new BSTNode(node->value);
                    temp->right = node->right;
                    temp->left = node->left;
                    temp = node->right;
                    parent = node;
                    int k = 0;
                    //find successor
                    while(temp->left != NULL){
                        temp = temp->left;
                    }
                    //call remove function to remove the successor
                    isRoot = true;
                    isSuccessor = true;
                    remove_node(root, temp->value, isRoot, root, isSuccessor);
                    //set node = to the successor values
                    node->value = temp->value;
                    node->count = temp->count;
                }
                //if num is greater than root and is root is false set up node and parent node
            }else if(num > node->value && isRoot == false){
                node = node->right;
                if(num > parent->value){
                    parent = parent->right;
                }else{
                    parent = parent->left;
                }
                remove_node(node, num, isRoot, parent, isSuccessor);
                //same for less than
            }else if(num < node->value && isRoot == false){
                node = node->left;
                if(num > parent->value){
                    parent = parent->right;
                }else{
                    parent = parent->left;
                }
                remove_node(node, num, isRoot, parent, isSuccessor);
                //if is root is true dont move parent yet
            }else if(num < node->value && isRoot == true){
                node = node->left;
                isRoot = false;
                remove_node(node, num, isRoot, parent, isSuccessor);
            }else{
                //same for greater than
                node = node->right;
                isRoot = false;
                remove_node(node, num, isRoot, parent, isSuccessor);
            }
        }
        
        const int findContains(BSTNode *node, const int num){
            //if the value of the node is = to the num return found
            if(node->value == num){
                return 1;
                //move down tree to right
            }else if(num > node->value){
                if(node->right != NULL){
                    node = node->right;
                    return findContains(node, num);
                }else{
                    // if you get to the end of the path and it  points to null the number does not exits
                    return 0;
                }
            }else{
                //same for left hand side
                if(node->left != NULL){
                    node = node->left;
                    return findContains(node, num);
                }else{
                    return 0;
                }
            }
        }
        
        unsigned int findSize(BSTNode *node){
            //if node is a leaf return 1
            if(node->right == NULL && node->left == NULL){
                return 1;
                //add 1 and traverse down left of list
            }else if(node->right == NULL && node->left != NULL){
                return 1 + findSize(node->left);
                //add one and traverse down right of list
            }else if(node->right != NULL && node->left == NULL){
                return 1 + findSize(node->right);
            }else{
                return 1 + findSize(node->right) + findSize(node->left);
            }
        }
        
        int node_print(BSTNode *node){
            //if node does not exist do not print anything
            if(node == NULL){
                return 0;
            }
            //if there are nodes avaliabe to the left traverse down left of list
            if(node->left != NULL){
                node_print(node->left);
            }
            //print the value at that node
            cout<< node->value << " " << node->count  << endl;
            //if there are avaiable right nodes traverse down right
            if(node->right != NULL){
                node_print(node->right);
            }
        }
        
        int node_range_search(BSTNode *node, const int l, const int r, std::vector<int> *range){
            //traverse down list until end is foudn
            if(node == NULL){
                return 0;
            }else{
                //if the node is between the two values return 
                if(node->value >= l && node->value <= r){
                    range->push_back(node->value);
                }
                //preoder traversal
                node_range_search(node->left, l, r, range);
                node_range_search(node->right, l, r, range);
            }
            return 0;
        }

    public:
        // DO NOT change any of the public methods
        // they should remain intact, so the Autograder can grade your work

        // Q1 -- 5 pts
        // constructor/destructor of the tree
        BSTree();
        ~BSTree();

        // Q2 -- 20 pts
        // if the integer already exists in the tree, just update the counter
        // otherwise make an insertion of a new value
        void insert(const int num);

        // Q3 -- 5 pts
        // returns 1 if the integer exists in the tree
        // 0 otherwise
        int contains(const int num);

        // Q4 -- 20 pts
        // if there is more than one occurrence of the integer in the tree
        // decrease the counter, otherwise delete the node
        void remove(const int num);

        // Q5 -- 5 pts
        // returns 1 if the tree is empty, 0 otherwise
        int empty();

        // Q6 -- 5 pts
        // returns how many different integers are in the tree
        unsigned int size();

        // Q7 -- 10 pts
        // removes all nodes from the tree and initializes all data members
        void clear();

        // Q8 -- 20 pts
        // returns in `range` all the integers in the interval [l,r]
        // returned values must appear in the same ordering as given by
        // a preorder traversal
        void range_search(const int l, const int r, std::vector<int> *range);

        // Q9 -- 10 pts
        // print (to the standard output) the frequency table in numerical
        // non-decreasing order using this format: one element of the tree should
        // be printed per line.  Each line must contain the integer value,
        // followed by one whitespace, followed by the number of occurrences of
        // that integer in the tree.
        // (to earn points in this question you need a correct solution for `insert`)
        void print_all();
};

#endif