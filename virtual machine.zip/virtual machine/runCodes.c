#include "runCodes.h"
#include "bitpack.h"
#include "memAccess.h"

#define TWO_TO_THE_THIRTY_TWO 4294967296
#define INSTRUCTION_NUM_WIDTH 4
#define INSTRUCTION_NUM_LSB 28

// Private instruction functions
void conditionalMove(struct abc_register_indexes indexes);
void segmentedLoad(struct abc_register_indexes indexes);
void segmentedStore(struct abc_register_indexes indexes);
void addition(struct abc_register_indexes indexes);
void multiplication(struct abc_register_indexes indexes);
void division(struct abc_register_indexes indexes);
void bitwiseNAND(struct abc_register_indexes indexes);
void halt();
void mapSegment(struct abc_register_indexes indexes);
void unmapSegment(struct abc_register_indexes indexes);
void output(struct abc_register_indexes indexes);
void input(struct abc_register_indexes indexes);
void loadProgram(struct abc_register_indexes indexes);
void loadValue(uint32_t instruction);

// Private helper functions
void callInstruction(uint32_t instructionNumber, uint32_t instruction);

// Array of 8 registers with each value initialized to 0
uint32_t r[8] = {0};

// Pointer to current memory location in the program segment
uint32_t programCounter;

void runProgram(){
    uint32_t instruction = 0;
    uint32_t instructionNum = 0;
  programCounter = 0;

    while(1){

        instruction = getMemoryAt(0, programCounter);

        instructionNum = Bitpack_getu(instruction, INSTRUCTION_NUM_WIDTH,
                                        INSTRUCTION_NUM_LSB);

        callInstruction(instructionNum, instruction);

        if(instructionNum != loadProgramNum){
            programCounter++;
      }
    }
}

void callInstruction(uint32_t instructionNumber, uint32_t instruction){

    struct abc_register_indexes indexes;
    indexes.rA =  (uint32_t)Bitpack_getu(instruction, abcWidth, aLSB);
    indexes.rB =  (uint32_t)Bitpack_getu(instruction, abcWidth, bLSB);
    indexes.rC =  (uint32_t)Bitpack_getu(instruction, abcWidth, cLSB);

    switch (instructionNumber) {
        case conditionalMoveNum:
            conditionalMove(indexes);
            break;
        case segmentedLoadNum:
            segmentedLoad(indexes);
            break;
        case segmentedStoreNum:
            segmentedStore(indexes);
            break;
        case additionNum:
            addition(indexes);
            break;
        case multiplicationNum:
            multiplication(indexes);
            break;
        case divisionNum:
            division(indexes);
            break;
        case bitwiseNANDNum:
            bitwiseNAND(indexes);
            break;
        case haltNum:
            halt();
            break;
        case mapSegmentNum:
            mapSegment(indexes);
            break;
        case unmapSegmentNum:
            unmapSegment(indexes);
            break;
        case outputNum:
            output(indexes);
            break;
        case inputNum:
            input(indexes);
            break;
        case loadProgramNum:
            loadProgram(indexes);
            break;
        case loadValueNum:
            loadValue(instruction);
            break;
        default:
            fprintf(stderr, "invalid instruction\n");
    }
}

void conditionalMove(struct abc_register_indexes indexes){
    if(r[indexes.rC]!= 0){
        r[indexes.rA] = r[indexes.rB];
    }
}

void segmentedLoad(struct abc_register_indexes indexes){
    r[indexes.rA] = getMemoryAt(r[indexes.rB], r[indexes.rC]);
}

void segmentedStore(struct abc_register_indexes indexes){
    setMemoryAt(r[indexes.rA], r[indexes.rB], r[indexes.rC]);
}

void addition(struct abc_register_indexes indexes){
    r[indexes.rA] = (r[indexes.rB] + r[indexes.rC]) % TWO_TO_THE_THIRTY_TWO;
}

void multiplication(struct abc_register_indexes indexes){
    r[indexes.rA] = (r[indexes.rB] * r[indexes.rC]) % TWO_TO_THE_THIRTY_TWO;
}

void division(struct abc_register_indexes indexes){
    r[indexes.rA] = (r[indexes.rB] / r[indexes.rC]);
}

void bitwiseNAND(struct abc_register_indexes indexes){
    r[indexes.rA] = ~(r[indexes.rB] & r[indexes.rC]);
}

void halt(){
    exit(0);
}

void mapSegment(struct abc_register_indexes indexes){
    r[indexes.rB] = activateSegment(r[indexes.rC]);
}

void unmapSegment(struct abc_register_indexes indexes){
    deactivateSegment(r[indexes.rC]);
}

void output(struct abc_register_indexes indexes){
    if(r[indexes.rC] <= 255){
        putc(r[indexes.rC], stdout);
    }
}

void input(struct abc_register_indexes indexes){
    int c = getc(stdin);

    if(c < 0 || c > 255){
        exit(1);
    }

    if(c == EOF){
        uint32_t ones = 0xFFFFFFFF;
        r[indexes.rC] = ones;
    } else{
        r[indexes.rC] = (uint32_t) c;
    }
}

void loadProgram(struct abc_register_indexes indexes){

    if(r[indexes.rB] != 0){
        moveSegment(r[indexes.rB], 0);
        deactivateSegment(r[indexes.rB]);
    }

  programCounter = r[indexes.rC];

}

void loadValue(uint32_t instruction){
    uint32_t A = (uint32_t) Bitpack_getu(instruction, abcWidth, 25);
    r[A] = (uint32_t) Bitpack_getu(instruction, 25, 0);
}
