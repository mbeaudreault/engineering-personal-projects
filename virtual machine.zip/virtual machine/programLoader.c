#include "programLoader.h"
#include <stdio.h>
#include <stdlib.h>
#include "bitpack.h"
#include "memAccess.h"

uint32_t getFileNumWords(FILE *programFile){
    //Source :
    //https://stackoverflow.com/questions/238603/how-can-i-get-a-files-size-in-c
    fseek(programFile, 0, SEEK_END);
    uint32_t numWords = ftell(programFile)/4;
    fseek(programFile, 0, SEEK_SET);
    return numWords;
}

void loadProgramFile(FILE *programFile){

    uint32_t numWords = getFileNumWords(programFile);

    for(uint32_t i = 0; i < numWords; i++){
        uint32_t word = 0;

    word = (uint32_t)Bitpack_newu(word, 8, 24, (uint64_t)getc(programFile));
    word = (uint32_t)Bitpack_newu(word, 8, 16, (uint64_t)getc(programFile));
    word = (uint32_t)Bitpack_newu(word, 8, 8, (uint64_t)getc(programFile));
    word = (uint32_t)Bitpack_newu(word, 8, 0, (uint64_t) getc(programFile));

        setMemoryAt(0, i, word);
    }
}
