//g++ -std=c++11 main1.cc stack.cc
//./a.out
#include "stack.h"

#include <iostream>

using namespace std;


int main(){
    ListStack *q1 = new ListStack;
    string input;
    int data;
    int currentSize;
    string pop = "pop";
    while(cin >> input){
        if(input.compare(pop) == 0){
            q1->pop();
        }else{
            cin >> data;
            q1->push(data);
        }
    }
    currentSize = q1->size();
    int answerArray[currentSize];
    for(int j = 0; j < currentSize; j++){
        answerArray[j] = q1->pop();
    }
    for(int i = currentSize -1 ; i >= 0; i--){
        if(i != 0){
            cout << answerArray[i] << " ";
        }else{
            cout << answerArray[i];
        }
    }
    return 0;
}