#include "bitpack.h"
#include "except.h"
#include <math.h>
#include <stdio.h>

Except_T Bitpack_Overflow = {"Overflow packing bits"};

bool Bitpack_fitsu(uint64_t n, unsigned width){
    if(width == 64){
        width = 63;
    }
    uint64_t min = 0;
    uint64_t max = 0;
    for(unsigned i = 0; i < width; i++){
        max += pow(2, i);
    }
    if(n <= max && n >= min){
        return 1;
    }else{
        return 0;
    }
}

bool Bitpack_fitss(int64_t n, unsigned width){
    int64_t min = -1 * pow(2, width-1);
    int64_t max = 0;
    for(unsigned i = 0; i < width-1; i++){
        max += pow(2, i);
    }
    if(n <= max && n >= min){
        return 1;
    }else{
        return 0;
    }
}

uint64_t Bitpack_getu(uint64_t word, unsigned width, unsigned lsb){
    if(width == 0){
        word = 0;
    }else{
        word <<= 64 - (width + lsb);
        word >>= 64 - width;
    }

    return word;
}

int64_t Bitpack_gets(uint64_t word, unsigned width, unsigned lsb){
    int64_t intWord;
    if(width == 0){
        intWord = 0;
    }else{
        word <<= 64 - (width + lsb);
        intWord = (int64_t)word;
        intWord >>= 64 - width;
    }
    return intWord;
}

uint64_t Bitpack_newu(uint64_t word, unsigned width, unsigned lsb,
 uint64_t value){

    if((width > 64) || ((width + lsb) > 64)){
        RAISE(Bitpack_Overflow);
    }
    if(!Bitpack_fitsu(value, width)){
        RAISE(Bitpack_Overflow);
    }

 uint64_t shiftedValue;
    if(lsb == 64){
        shiftedValue = 0;
    }else{
        uint64_t ones = 0xFFFFFFFFFFFFFFFF;
        ones >>= lsb;
        ones <<= lsb;
        ones <<= 64 - (width + lsb);
        ones >>= 64 - (width + lsb);
        ones = ~ones;
      word = word & ones;
        shiftedValue = value << lsb;
    }

    uint64_t returnedWord = word | shiftedValue;

    return returnedWord;
}

uint64_t Bitpack_news(uint64_t word, unsigned width, unsigned lsb, 
int64_t value){
    if((width > 64) || ((width + lsb) > 64)){
        RAISE(Bitpack_Overflow);
    }
    if(!Bitpack_fitss(value, width)){
        RAISE(Bitpack_Overflow);
    }
    uint64_t newValue = (uint64_t)value;
    if((64 - width) == 64){
        newValue = 0;
    }else{
        newValue <<= (64 - width);
        newValue >>= (64 - width);
    }

    return Bitpack_newu(word, width, lsb, newValue);
}
