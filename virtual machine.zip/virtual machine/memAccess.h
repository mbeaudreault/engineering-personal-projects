/*
 * Nick Ryan and Matthew Beaudreault
 * programLoader.h
 *
 * Provides an interface for managing the universal machines memory
 * allowing for work with whole segments and individual words within segments
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "array.h"
#include "seq.h"
#include <stdbool.h>

/* Create the structure to be used as memory for the programs */
void initializeMemory(uint32_t numWords);

/* Takes the segment number out of the pool and 
   allocates memory for the segment */
uint32_t activateSegment(uint32_t numWords);

/* Puts the segment number back into a pool to be used and frees its memory */
void deactivateSegment(uint32_t segNum);

/* Gets the 32 bit word at this location */
uint32_t getMemoryAt(uint32_t segNum, uint32_t memLoc);

/* Sets the 32 bit word at this location to value */
void setMemoryAt(uint32_t segNum, uint32_t memLoc, uint32_t inputValue);

/* Moves the segment stored at oldSegNum into the location of newSegNum */
void moveSegment(uint32_t oldSegNum, uint32_t newSegNum);

/* Gives the number of words allocated for the given segment */
uint32_t getNumWords(uint32_t segNum);

/* Frees all memory not yet freed through deactivation */
void freeAllMemory();
