/*
 * Nick Ryan and Matthew Beaudreault
 * runCodes.h
 *
 * An interface for running the program stored in segment 0
 * of the universal machine's memory
 *
 * Defines abc_register_indexes which stores the current values
 * of rA, rB, and rC read from an instruction
 *
 * Defines abc_reg_bit_positions which stores the offset and abcWidth
 * for registers rA, rB, and rC
 *
 * Defines instructions which has the number for each instruction
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

typedef struct abc_register_indexes {
  uint32_t rA, rB, rC;
} *abc_register_indexes;

enum abc_reg_bit_positions { aLSB = 6, bLSB = 3, cLSB = 0, abcWidth = 3 };

enum instructions {conditionalMoveNum = 0, segmentedLoadNum, segmentedStoreNum,
                   additionNum, multiplicationNum, divisionNum, bitwiseNANDNum,
                   haltNum, mapSegmentNum, unmapSegmentNum, outputNum, 
                   inputNum, loadProgramNum, loadValueNum};

/* Runs through a program's instructions starting at m[0][0] */
void runProgram();
