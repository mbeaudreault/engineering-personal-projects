#include "bstree.h"
#include<iostream>
using namespace std;


BSTree::BSTree(){
    root = NULL;
    n_elem = 0;
}

BSTree::~BSTree(){
    
}

void BSTree::insert(const int num){
    if(root == NULL){
        root = new BSTNode(num);
    }else{
        BSTree::insert_Node(root, num);
    }
}

int BSTree::contains(const int num){
    if(root == NULL){
        return 0;
    }else{
        return BSTree::findContains(root, num);
    }
}

void BSTree::remove(const int num){
    if(root != NULL && root->right == NULL && root->left == NULL){
        root = NULL;
    }else if(root->value == num && root->right != NULL && root->left != NULL && size() == 3){
        root->value = root->left->value;
        root->count = root->left->count;
        root->left = NULL;
    }else if(root->value == num && root ->right != NULL && root->left == NULL){
        root = root->right;
    }else if(root->value == num && root->left != NULL && root->right == NULL){
        root = root->left;
    }else if(contains(num) == 0){
        
    }else{
       BSTree::remove_node(root, num, true, root, false); 
    }
}

int BSTree::empty(){
    if(root == NULL){
        return 1;
    }else{
        return 0;
    }
}

unsigned int BSTree::size(){
    unsigned int size = 0;
    if(root == NULL){
        return 0;
    }else{
        size = BSTree::findSize(root);
        return BSTree::findSize(root);
    }
}

void BSTree::clear(){
    root->right = NULL;
    root->left = NULL;
    root = NULL;
}

void BSTree::range_search(const int l, const int r, std::vector<int> *range){
    if(root == NULL){
        
    }else{
        BSTree::node_range_search(root, l, r, range);
    }
}

void BSTree::print_all(){
    if(root == NULL){
        
    }else{
        node_print(root);
    }
}


