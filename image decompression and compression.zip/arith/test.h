#include "compress.h"
#include "pnm.h"
#include "a2plain.h"
#include "mem.h"
#include "bitpack.h"
#include "arith.h"
#include <math.h>
#include "assert.h"
#include "compression.h"
#include "decompression.h"

extern int testRGBConversion(FILE *input);
extern void testYPbPrtoABCD(FILE *input);
extern A2Methods_Array2 pack2by2Test(A2Methods_Array2 componentArray, Pnm_ppm image);
