#include "pnm.h"
#include "a2plain.h"
#include "mem.h"
#include "bitpack.h"
#include "arith.h"
#include <math.h>
#include "assert.h"

#define DENOMINATOR 255

extern void getYPbPr(unsigned a, int b, int c, int d,
   unsigned pb, unsigned pr, A2Methods_Array2 YPbPrArray, unsigned i, unsigned j);

extern A2Methods_Array2 YPbPrtoRGB(A2Methods_Array2 YPbPrArray, A2Methods_Array2 rgbDecompressedFloatArray, unsigned width, unsigned height);
void floatRGBtoPpmRGB(struct Pnm_ppm pixmap, A2Methods_Array2 rgbDecompressedFloatArray);

extern void printImage(void* imageArray, Pnm_ppm inputImage);
