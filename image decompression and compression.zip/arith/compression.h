#include "pnm.h"
#include "a2plain.h"
#include "mem.h"
#include "bitpack.h"
#include "arith.h"
#include <math.h>
#include "assert.h"

typedef struct Pnm_float_rgb { // colored pixel (scaled integers)
  float red, green, blue;
} *Pnm_float_rgb;

typedef struct Pnm_float_YPbPr { // colored pixel (scaled integers)
  float Y, Pb, Pr;
} *Pnm_float_YPbPr;

extern A2Methods_Array2 formatImage(Pnm_ppm image);
extern A2Methods_Array2 RGBtoYPbPr(A2Methods_Array2 floatArray, Pnm_ppm image);
extern A2Methods_Array2 pack2by2(A2Methods_Array2 componentArray, Pnm_ppm image);
extern signed floatToSigned(float xfloat);
extern void printCompressed(A2Methods_Array2 wordArray, Pnm_ppm image);
