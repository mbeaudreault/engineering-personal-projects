#include <stdio.h>
#include <stdlib.h>
#include "assert.h"
#include "pnmrdr.h"
#include <math.h>

//2 ways to interact with ppm files, you dont have to submit ppmdiff
double rootMeanSquareDifference(Pnmrdr_mapdata data1, Pnmrdr_mapdata data2, Pnmrdr_T pgm1, Pnmrdr_T pgm2);

int main(int argc, char* argv[]){
  assert(argc == 3);

  //if(argc == 3){
     FILE *file1 = fopen(argv[1], "r");
     FILE *file2 = fopen(argv[2], "r");

     Pnmrdr_T pgm1 = Pnmrdr_new(file1);
     Pnmrdr_T pgm2 = Pnmrdr_new(file2);

     Pnmrdr_mapdata data1 = Pnmrdr_data(pgm1);
     Pnmrdr_mapdata data2 = Pnmrdr_data(pgm2);

     if(abs(data1.height - data2.height) > 1 ||
        abs(data1.width - data2.width) > 1){
        printf("1.0\n");
        fprintf(stderr, "Image width or height difference too great\n");
      }

      rootMeanSquareDifference(data1, data2, pgm1, pgm2);
  //}

  return 0;
}

double rootMeanSquareDifference(Pnmrdr_mapdata data1, Pnmrdr_mapdata data2, Pnmrdr_T pgm1, Pnmrdr_T pgm2){
 int height = 0;
 int width = 0;
 Pnmrdr_T largerImage;
 Pnmrdr_T smallerImage;
 double sum = 0;
 double E = 0;

  if(data1.height >= data2.height){
    height = data2.height;
  }else{
    height = data1.height;
  }

  if(data1.width >= data2.width){
    width = data2.width;
    largerImage = pgm1;
    smallerImage = pgm2;
  }else{
    width = data1.width;
    largerImage = pgm2;
    smallerImage = pgm1;
  }
  for(int i = 0; i < height; i++){
    for(int j = 0; j < width; j++){
      unsigned pixel1Red = Pnmrdr_get(largerImage);
      unsigned pixel1Green = Pnmrdr_get(largerImage);
      unsigned pixel1Blue = Pnmrdr_get(largerImage);
      unsigned pixel2Red = Pnmrdr_get(smallerImage);
      unsigned pixel2Green = Pnmrdr_get(smallerImage);
      unsigned pixel2Blue = Pnmrdr_get(smallerImage);

      //printf("Pixel 1 = %u %u %u, \n", pixel1Red, pixel1Green, pixel1Blue);
      //printf("Pixel 2 = %u %u %u, \n", pixel2Red, pixel2Green, pixel2Blue);
      sum += pow((abs(pixel2Red - pixel1Red)), 2)
          + pow((abs(pixel2Green - pixel1Green)), 2)
          + pow((abs(pixel2Blue - pixel1Blue)), 2); //<<<Ask about this
    }
    if(data1.width != data2.width){
      Pnmrdr_get(largerImage);
      Pnmrdr_get(largerImage);
      Pnmrdr_get(largerImage);
    }
  }
  printf("sum %f\n", sum);
  sum = sum / (3*width*height);
  E = sqrt(sum);
  printf("E = %f\n", E);
  return E;
}
