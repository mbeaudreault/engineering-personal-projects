/*
 * Nick Ryan and Matthew Beaudreault
 * programLoader.h
 *
 * Provides an interface for working with a univeral machine
 * program file and reading the program into memory
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

/* Takes a program file and loads the instructions into memory */
void loadProgramFile(FILE *programFile);

/* Finds the number of words in the file  */
uint32_t getFileNumWords(FILE *programFile);
