//g++ -std=c++11 main2.cc stack.cc
#include "stack.h"



#include <iostream>

using namespace std;

int main(){
    ListStack *q1 = new ListStack;
    string input;
    string number;
    int numExecutions;
    int num1;
    int num2;
    cin >> numExecutions;
    int totals[numExecutions];
    
    for(int i = 0; i < numExecutions; i++){
        while(cin >> number){
            if(number.compare("+") == 0){
                num1 = q1->pop();
                num2 = q1->pop();
                q1->push(num1 + num2);
            }else if(number.compare("-") == 0){
                num2 = q1->pop();
                num1 = q1->pop();
                q1->push(num1 - num2);
            }else if(number.compare("*") == 0){
                num2 = q1->pop();
                num1 = q1->pop();
                q1->push(num1*num2);
            }else if(number.compare("/") == 0){
                num2 = q1->pop();
                num1 = q1->pop();
                q1->push(num1 / num2);
            }else{
                q1->push(atoi(number.c_str()));
            }
        }
        totals[i] = q1->pop();
    }
    for(int j = numExecutions - 1; j >= 0; j--){
        cout << totals[j] << endl;
    }
}