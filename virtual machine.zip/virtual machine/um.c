#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdint.h>
#include "programLoader.h"
#include "memAccess.h"
#include "runCodes.h"

int main(int argc, char* argv[]){
    assert(argc == 2);

    FILE *programFile = fopen(argv[1], "r");
    assert(programFile != NULL);

    uint32_t numWords = getFileNumWords(programFile);
    initializeMemory(numWords);
    loadProgramFile(programFile);
  runProgram();
    freeAllMemory();

    return 0;
}
