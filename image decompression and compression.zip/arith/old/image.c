#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "assert.h"
#include "compress.h"
#include "bitpack.h"
#include "test.h"

// Don't forget to check for tabs and columns greater than 80!

static void (*compress_or_decompress)(FILE *input) = compress;

int main(int argc, char *argv[]) {
  int i;
  for (i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "-c")) {
	  compress_or_decompress = compress;
    } else if (!strcmp(argv[i], "-d")) {
	  compress_or_decompress = decompress;
    } else if (*argv[i] == '-') {
      fprintf(stderr, "%s: unknown option '%s'\n", argv[0], argv[i]);
      exit(1);
    } else if (argc - i > 2) {
      fprintf(stderr, "Usage: %s -d [filename]\n"
                      "       %s -c [filename]\n", argv[0], argv[0]);
      exit(1);
    } else {
      break;
    }
  }
  assert(argc - i <= 1); // at most one file on command line
  if (i < argc) {
    FILE* fp = fopen(argv[i], "r");
    assert(fp);
    //testYPbPrtoABCD(fp);
    compress_or_decompress(fp);
    fclose(fp);
  } else {
    compress_or_decompress(stdin);
  }

  //printf("unsigned = %d\n", Bitpack_fitss(3,3));
  //printf("newu = %lx\n", Bitpack_newu(0, 4, 2, 7));
  //printf("news = %lx\n", Bitpack_news(0, 4, 2, -4));
  //printf("getu = %ld\n", Bitpack_gets(0x0000FF00, 4, 8));

}
