#include "compress.h"
#include "compression.h"
#include "decompression.h"

// reads PPM and writes a compressed image
extern void compress(FILE *input){
	Pnm_ppm image = Pnm_ppmread(input, array2_methods_plain);
	A2Methods_Array2 floatArray = formatImage(image);

  A2Methods_Array2 componentArray = RGBtoYPbPr(floatArray, image);

  A2Methods_Array2 wordArray = pack2by2(componentArray, image);
  //uint64_t *tempWord = (image->methods->at)(wordArray, 0, 2);
  //printf("out word = %lx\n", *tempWord);

  printCompressed(wordArray, image);

  //printf("Y = %f\n", ((Pnm_float_YPbPr)((image->methods->at)(componentArray, 0, 0)))->Y);
	(void) image;
}

// reads a compressed image and writes PPM
extern void decompress(FILE *input){
  unsigned height, width;
  int read = fscanf(input, "Compressed image format 2\n%u %u", &width, &height);
  //printf("read = %d\n", read);
  assert(read == 2);

  // Checks for newline
  int newLine = getc(input);
  assert(newLine == '\n');

  A2Methods_Array2 pixelArray = (array2_methods_plain->new)(width, height, sizeof(struct Pnm_rgb));
  int denominator = DENOMINATOR;

  struct Pnm_ppm pixmap = { .width = width, .height = height, .denominator = denominator, .pixels = pixelArray, .methods = array2_methods_plain };
  (void)pixmap;


  //c = getc(input);
  unsigned a, pb, pr;
  int b,c,d;
  A2Methods_Array2 YPbPrArray = (array2_methods_plain->new)(width, height, sizeof(struct Pnm_float_YPbPr));
  A2Methods_Array2 rgbDecompressedFloatArray = (array2_methods_plain->new)(width, height, sizeof(struct Pnm_float_rgb));
  for(unsigned i = 0; i < height; i += 2){
    for(unsigned j = 0; j < width; j+=2 ){

			/*a = getc(input);
      b = getc(input);
      c = getc(input);
      d = getc(input);
      pb = getc(input);
      pr = getc(input);*/

	  	uint64_t word = 0;
	  	word = Bitpack_newu(word, 8, 24, (uint64_t)getc(input));
	  	word = Bitpack_newu(word, 8, 16, (uint64_t)getc(input));
	  	word = Bitpack_newu(word, 8, 8, (uint64_t)getc(input));
	  	word = Bitpack_newu(word, 8, 0, (uint64_t) getc(input));

			//printf("word = %lx\n", word);

	  	a = Bitpack_getu(word, 9, 23);
    	b = Bitpack_gets(word, 5, 18);
    	c = Bitpack_gets(word, 5, 13);
    	d = Bitpack_gets(word, 5, 8);
    	pb = Bitpack_getu(word, 4, 4);
    	pr = Bitpack_getu(word, 4, 0);

			//printf("a = %u, b = %d, c = %d, d = %d\n\n", a , b, c ,d);

    	getYPbPr(a, b, c, d, pb, pr, YPbPrArray, i, j);

      //printf("c = %d\n", c);
    }
  }
  YPbPrtoRGB(YPbPrArray, rgbDecompressedFloatArray, width, height);
  floatRGBtoPpmRGB(pixmap, rgbDecompressedFloatArray);

  Pnm_ppmwrite(stdout, &pixmap); // prints ppm (P6) which is not readable as a text file
}
