#include "test.h"
#include <math.h>
#include <except.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct abcdTest { // colored pixel (scaled integers)
  unsigned a, Pb, Pr;
  int b,c,d;
} *abcdTest;

int testRGBConversion(FILE *input){
  Pnm_ppm image = Pnm_ppmread(input, array2_methods_plain);
  A2Methods_Array2 floatArray = formatImage(image);
  A2Methods_Array2 rgbDecompressedFloatArray = (array2_methods_plain->new)(image->width, image->height, sizeof(struct Pnm_float_rgb));


  YPbPrtoRGB(RGBtoYPbPr(floatArray, image), rgbDecompressedFloatArray, image->width, image->height);

  for(unsigned i = 0; i < image->height; i++){
    for(unsigned j = 0; j < image->width; j++){
      Pnm_float_rgb beforePixel = (array2_methods_plain->at)(floatArray, j, i);
      Pnm_float_rgb afterPixel = (array2_methods_plain->at)(rgbDecompressedFloatArray, j, i);
      //printf("before red = %f green = %f blue = %f, i = %u, j = %u\n",  beforePixel->red, beforePixel->green, beforePixel->blue, i , j);
      //printf("after red = %f green = %f, blue = %f, i = %u, j = %u\n", afterPixel->red, afterPixel->green, afterPixel->blue, i, j);
      if(fabs(beforePixel->red - afterPixel->red) > 0.1){
        printf("wrong red at i = %u, j = %u before value = %f, after value = %f\n", i, j, beforePixel->red, afterPixel->red);
      }
      if(fabs(beforePixel->green - afterPixel->green) > 0.1){
        printf("wrong green at i = %u, j =  %u before value = %f, after value = %f\n", i, j, beforePixel->green, afterPixel->green);
      }
      if(fabs(beforePixel->blue - afterPixel->blue) > 0.1){
        printf("wrong blue at i = %u, j = %u before value = %f, after value = %f\n", i, j, beforePixel->blue, afterPixel->blue);
      }
    }
  }
  return 0;
}

// Check YPbPr array against component array
void testYPbPrtoABCD(FILE *input){
  Pnm_ppm image = Pnm_ppmread(input, array2_methods_plain);
  A2Methods_Array2 floatArray = formatImage(image);

  A2Methods_Array2 componentArray = RGBtoYPbPr(floatArray, image);
  A2Methods_Array2 beforeABCD = pack2by2Test(componentArray, image);


  A2Methods_Array2 YPbPrArray = (array2_methods_plain->new)(image->width, image->height, sizeof(struct Pnm_float_YPbPr));

  // convert back from abcd to ypbpr
  for(unsigned i = 0; i < image->height; i += 2){
    for(unsigned j = 0; j < image->width; j+=2 ){
      abcdTest beforePixel = (array2_methods_plain->at)(beforeABCD, j, i);
      getYPbPr(beforePixel->a, beforePixel->b, beforePixel->c, beforePixel->d, beforePixel->Pb, beforePixel->Pr, YPbPrArray, i, j);
    }
  }

  // compare before and after
  for(unsigned i = 0; i < image->height; i++){
    for(unsigned j = 0; j < image->width - 1; j++){
      Pnm_float_YPbPr beforePixel = (array2_methods_plain->at)(componentArray, j, i);
      Pnm_float_YPbPr beforePixel1 = (array2_methods_plain->at)(componentArray, j, i);
      Pnm_float_YPbPr beforePixel2 = (array2_methods_plain->at)(componentArray, j, i+1);
      Pnm_float_YPbPr beforePixel3 = (array2_methods_plain->at)(componentArray, j+1, i);
      Pnm_float_YPbPr beforePixel4 = (array2_methods_plain->at)(componentArray, j+1, i+1);

      float beforePixelPb = (beforePixel1->Pb + beforePixel2->Pb + beforePixel3->Pb + beforePixel4->Pb)/4.0;
      float beforePixelPr = (beforePixel1->Pr + beforePixel2->Pr + beforePixel3->Pr + beforePixel4->Pr)/4.0;

      Pnm_float_YPbPr afterPixel = (array2_methods_plain->at)(YPbPrArray, j, i);
      printf("Y = %f, Pb = %f, Pr = %f, i = %u, j = %u\n", beforePixel->Y, beforePixelPb, beforePixelPr, i, j);
      printf("Y = %f, Pb = %f, Pr = %f, i = %u, j = %u\n", afterPixel->Y, afterPixel->Pb, afterPixel->Pr, i, j);
      printf("\n");
    }
  }
}


A2Methods_Array2 pack2by2Test(A2Methods_Array2 componentArray, Pnm_ppm image){
  A2Methods_Array2 abcdArray = (image->methods->new)(image->width, image->height, sizeof(abcdTest));

  for(unsigned i = 0; i < image->height; i += 2){
    for(unsigned j = 0; j < image->width; j += 2){
      Pnm_float_YPbPr pixel1 = (image->methods->at)(componentArray, j, i);
      Pnm_float_YPbPr pixel2 = (image->methods->at)(componentArray, j, i+1);
      Pnm_float_YPbPr pixel3 = (image->methods->at)(componentArray, j+1, i);
      Pnm_float_YPbPr pixel4 = (image->methods->at)(componentArray, j+1, i+1);

      float PbAvg = ((pixel1->Pb + pixel2->Pb + pixel3->Pb + pixel4->Pb) / 4.0);
      float PrAvg = ((pixel1->Pr + pixel2->Pr + pixel3->Pr + pixel4->Pr) / 4.0);

      unsigned PbAvg4b = Arith_index_of_chroma(PbAvg);
      unsigned PrAvg4b = Arith_index_of_chroma(PrAvg);

      printf("PbAvg = %f, PrAvg = %f, i = %u, j = %u\n", PbAvg, PrAvg, i, j);
      //printf("PbAvg4b = %u, PrAvg4b = %u, i = %u, j = %u\n", PbAvg4b, PrAvg4b, i, j);

      float aFloat = ((pixel4->Y + pixel3->Y + pixel2->Y + pixel1->Y)/4.0);
      float bFloat = ((pixel4->Y + pixel3->Y - pixel2->Y - pixel1->Y)/4.0);
      float cFloat = ((pixel4->Y - pixel3->Y + pixel2->Y - pixel1->Y)/4.0);
      float dFloat = ((pixel4->Y - pixel3->Y - pixel2->Y + pixel1->Y)/4.0);

      unsigned a = (unsigned)(round(aFloat * 511.0));
      signed b = floatToSigned(bFloat);
      signed c = floatToSigned(cFloat);
      signed d = floatToSigned(dFloat);

      printf("a = %u, b = %d, c = %d, d = %d, i = %u, j = %u\n", a, b, c, d, i, j);
      //printf("pb = %f, pr = %f \n", PbAvg, PrAvg);

      abcdTest tempSquare = (image->methods->at)(abcdArray, j, i);
      tempSquare->a = a;
      tempSquare->b = b;
      tempSquare->c = c;
      tempSquare->d = d;
      tempSquare->Pb = PbAvg4b;
      tempSquare->Pr = PrAvg4b;
    }
  }
  return abcdArray;
}

void check_laws(uint64_t word, unsigned w, unsigned lsb, uint64_t value, unsigned w2, unsigned lsb2){
  if(w2 == w && lsb2 == lsb){
    printf("here\n");
    if(Bitpack_getu(Bitpack_newu(word, w, lsb, value), w, lsb) == value){
      printf("passed\n");
    }else{
      printf("Return value does not match: \nword = %lx, width = %u, lsb = %u, value = %lx \n w2 = %u, lsb2 = %u\n\n", word, w, lsb, value, w2, lsb2);
    }
    if(Bitpack_getu(Bitpack_newu(word, w, lsb, value), w2, lsb2) == Bitpack_getu(word, w2, lsb2)){

    }
    else{
      printf("Exception raised during testing: \nword = %lx, width = %u, lsb = %u, value = %lx \n w2 = %u, lsb2 = %u\n\n", word, w, lsb, value, w2, lsb2);
    }
  }
}

int main(){
  //uint64_t word = 0;
  //unsigned w = 3;
  //unsigned lsb = 2;
  //uint64_t value = 7;

  FILE *randfp = fopen("/dev/urandom", "rb");
  assert(randfp);

  for(unsigned w = 0; w <= 64; w++){
    for(unsigned lsb = 0; lsb + w <= 64; lsb++){
      for(unsigned trial = 0; trial < 1000; trial++) {
        // 1000 random trials
        //... set values of other parameters randomly
        uint64_t word;
        size_t rc = fread(&word, sizeof(word), 1, randfp);
        assert(rc == 1);

        uint64_t value;
        size_t vc = fread(&value, sizeof(value), 1, randfp);
        assert(vc == 1);
        if(w == 0){
          value = 0;
        }else{
          value >>= 64 - w;
        }

        //srand(time(0));

        //w2 = rand() % 65;
        //lsb2 = rand() % 65;
        unsigned w2 = w;
        unsigned lsb2 = lsb;
        check_laws(word, w, lsb, value, w2, lsb2);
      }
    }
  }
  return 0;
}
